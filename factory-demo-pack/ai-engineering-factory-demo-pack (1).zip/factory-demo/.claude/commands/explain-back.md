---
description: explain-back — governed pipeline step (see .github/prompts/explain-back.prompt.md)
---

Read `.github/prompts/explain-back.prompt.md` and follow it exactly as written.

That file is the single source of truth for this command. Do not summarise it,
do not substitute your own judgement for it, and do not proceed past any point
where it tells you to stop.

Arguments: $ARGUMENTS
